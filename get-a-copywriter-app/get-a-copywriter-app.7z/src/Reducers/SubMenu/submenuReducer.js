
const initialState = {

}

export default function subMenuActions(state = initialState, action){
    switch (action.type){

        default: 
        return state
    }
}