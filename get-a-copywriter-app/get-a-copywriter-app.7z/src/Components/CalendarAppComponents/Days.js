import React, { Component } from 'react';

class Days extends Component {
    render() {
        return(
            <div className='days'>
                <div className='day'>
                    <div>Sunday</div>
                </div>
                <div className='day'>
                    <div>Monday</div>
                </div>
                <div className='day'>
                    <div>Tuesday</div>
                </div>
                <div className='day'>
                    <div>Wednesday</div>
                </div>
                <div className='day'>
                    <div>Thursday</div>
                </div>
                <div className='day'>
                    <div>Friday</div>
                </div>
                <div className='day'>
                    <div>Saturday</div>
                </div>
            </div>
        )
    }
}

export default Days;